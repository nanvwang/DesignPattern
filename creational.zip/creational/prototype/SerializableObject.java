package designPattern.creational.prototype;

import java.io.Serializable;

public class SerializableObject implements Serializable {
	private static final long serialVersionUID = 1L;
}
