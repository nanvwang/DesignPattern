package designPattern.creational;

public interface Sender {

	void send();
}
