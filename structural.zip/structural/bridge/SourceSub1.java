package designPattern.structural.bridge;

public class SourceSub1 implements Sourceable{

    public void method(){
        System.out.println("method in sourceSub1!");
    }
}
