package designPattern.structural.bridge;

public interface Sourceable{

    void method();
}
