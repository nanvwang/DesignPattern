package designPattern.structural.bridge;

public class SourceSub2 implements Sourceable{

    public void method(){
        System.out.println("method in sourceSub2!");
    }

}
