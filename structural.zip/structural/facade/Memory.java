package designPattern.structural.facade;

public class Memory{

    public void startup(){
        System.out.println("memory startup!");
    }
    
    public void shutdown(){
        System.out.println("memory shutdown!");
    }
}
